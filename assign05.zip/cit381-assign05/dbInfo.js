exports.dbHost = "localhost";
exports.dbPort = "3306";
exports.dbUser = "root";
exports.dbPassword = "#password";
exports.dbDatabase = "381";